import time
import random
import datetime
from enum import Enum
from collections import deque
from std_msgs.msg import Float32MultiArray  # 구조만 사용
import random


# 유틸 함수 대체 (간단한 예시)
def create_pose(x, y, clock=None):
    class Pose:
        def __init__(self, x, y):
            self.position = type('Point', (), {"x": x, "y": y})
    class PoseStamped:
        def __init__(self, x, y):
            self.pose = Pose(x, y)
    return PoseStamped(x, y)

def euclidean(p1, p2):
    dx = p1.position.x - p2.position.x
    dy = p1.position.y - p2.position.y
    return (dx**2 + dy**2) ** 0.5

# ------------------------
# Enum: 로봇 상태 정의
# ------------------------
class RobotStatus(Enum):
    IDLE = "idle"
    WAIT = "wait"
    MOVING = "moving"
    FINISHED = "finished"
    RETURNING = "returning"

# ------------------------
# 로봇 FSM
# ------------------------
class RobotStateMachine:
    def __init__(self, name, init_pose, test_mode=True):
        self.name = name
        self.state = RobotStatus.IDLE
        self.init_pose = init_pose
        self.current_pose = init_pose.pose
        self.goal_pose = None
        self.goal_finished = False
        self.test_mode = test_mode

        self.box_id = None
        self.room_num = None
        self.delivery_start_time = None
        self.simulated_distance = 0.0

    def assign_goal(self, goal_pose, box_id=None, room_num=None):
        self.goal_pose = goal_pose
        self.box_id = box_id
        self.room_num = room_num
        self.delivery_start_time = time.time()
        self.simulated_distance = 0.0
        self.state = RobotStatus.MOVING
        if box_id is None and room_num is None:
            print(f"[{self.name}] 🔄 복귀 시작 (init pose로)")
        else:
            print(f"[{self.name}] 🛫 goal 할당 → box_id={box_id}, room={room_num}")

    def cancel_goal(self):
        print(f"[{self.name}] ❌ goal 취소 요청 (WAIT 진입)")
        self.simulated_distance = 0.0

    def tick(self, now, is_too_close):
        if self.state == RobotStatus.IDLE:
            print(f"[{self.name}] 🟢 상태: IDLE")
            return

        elif self.state == RobotStatus.MOVING:
            if is_too_close:
                print(f"[{self.name}] ⚠️ 충돌 감지 → 회피 대기(WAIT) 진입")
                self.cancel_goal()
                self.state = RobotStatus.WAIT
                return

            print(f"[{self.name}] 🚚 상태: MOVING (이동 중...)")
            self.simulated_distance += 0.5
            if self.simulated_distance > 3.0:
                self.goal_finished = True

            if self.goal_finished:
                self.goal_finished = False
                self.state = RobotStatus.FINISHED
                elapsed = time.time() - self.delivery_start_time
                print(f"[{self.name}] 📦 배송 완료! ⏱️ 소요: {elapsed:.2f}초")

        elif self.state == RobotStatus.WAIT:
            print(f"[{self.name}] ⏸️ 상태: WAIT (회피 대기 중...)")
            if not hasattr(self, "wait_start_time"):
                self.wait_start_time = time.time()

            if time.time() - self.wait_start_time > 3.0:
                print(f"[{self.name}] 🔄 wait 종료 → goal 재전송")
                self.assign_goal(self.goal_pose, self.box_id, self.room_num)
                self.state = RobotStatus.MOVING
                del self.wait_start_time

        elif self.state == RobotStatus.FINISHED:
            print(f"[{self.name}] ✅ 상태: FINISHED → 복귀 시작")
            self.assign_goal(self.init_pose)
            self.state = RobotStatus.RETURNING

        elif self.state == RobotStatus.RETURNING:
            if is_too_close:
                print(f"[{self.name}] ⚠️ 복귀 중 충돌 감지 → 회피 대기(WAIT)")
                self.cancel_goal()
                self.state = RobotStatus.WAIT
                return

            print(f"[{self.name}] 🔙 상태: RETURNING (복귀 중...)")
            self.simulated_distance += 0.5
            if self.simulated_distance > 2.0:
                self.state = RobotStatus.IDLE
                print(f"[{self.name}] 🏁 복귀 완료 → 상태: IDLE")

# ------------------------
# 테스트 TaskManager
# ------------------------
class DummyTaskManager:
    def __init__(self):
        self.robot_list = ["robot8", "robot9"]
        self.robots = {}
        self.goal_queue = deque()
        self.docking_sent = {name: False for name in self.robot_list}
        self.has_delivered_once = {name: False for name in self.robot_list}

        for name in self.robot_list:
            pose = create_pose(0.0 if name == "robot8" else 1.0, 0.0)
            self.robots[name] = RobotStateMachine(name, pose)

    def tick(self):
        now = time.time()
        close = random.random() < 0.5  # 10% 확률로 충돌

        # 1. IDLE 로봇에게 골고루 작업 할당
        idle_robots = [name for name, robot in self.robots.items() if robot.state == RobotStatus.IDLE]

        for name in idle_robots:
            if self.goal_queue:
                box_id, room_num, pose = self.goal_queue.popleft()
                self.robots[name].assign_goal(pose, box_id, room_num)

        # 2. 각 로봇 FSM 업데이트
        for name, robot in self.robots.items():
            robot.tick(now, close)

            # 3. 배송 완료 여부 체크
            if robot.state == RobotStatus.FINISHED:
                self.has_delivered_once[name] = True

        # 4. goal 없으면 랜덤하게 추가 (테스트 목적)
        if not self.goal_queue:
            for i in range(random.randint(1, 3)):
                goal = create_pose(random.uniform(1, 3), random.uniform(1, 3))
                self.goal_queue.append((f"test_box_{str(i)}", "101", goal))

        # 5. 도킹 조건 체크
        for name, robot in self.robots.items():
            if not self.goal_queue and self.has_delivered_once[name] and robot.state == RobotStatus.IDLE and not self.docking_sent[name]:
                self.docking_sent[name] = True
                print(f"[{name}] 🛰️ 도킹 신호 전송됨")

# ------------------------
# 메인 루프
# ------------------------
def main():
    manager = DummyTaskManager()
    try:
        while True:
            manager.tick()
            time.sleep(1.0)
    except KeyboardInterrupt:
        print("종료됨.")

if __name__ == "__main__":
    main()
