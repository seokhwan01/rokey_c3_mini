# import time
# from std_msgs.msg import Float32MultiArray
# from geometry_msgs.msg import PoseStamped
# from builtin_interfaces.msg import Time

# from TaskManager import RobotStateMachine, RobotStatus

# class DummyPublisher:
#     def publish(self, msg):
#         print(f"📤 [DUMMY] publish → {msg.data}")

# class DummyLogger:
#     def info(self, msg): print(f"[INFO] {msg}")
#     def warn(self, msg): print(f"[WARN] {msg}")

# def create_test_pose(x, y):
#     pose = PoseStamped()
#     pose.header.stamp = Time()
#     pose.pose.position.x = x
#     pose.pose.position.y = y
#     return pose

# def test_robot_fsm_with_collision_loop():
#     print("🧪 Robot FSM 충돌 및 대기 반복 시나리오 테스트...\n")

#     init_pose = create_test_pose(0.0, 0.0)
#     goal_pose = create_test_pose(2.0, 2.0)

#     robot = RobotStateMachine(
#         name="robot8",
#         init_pose=init_pose,
#         publisher=DummyPublisher(),
#         logger=DummyLogger()
#     )

#     # Step 1: goal 할당
#     robot.assign_goal(goal_pose)
#     assert robot.state == RobotStatus.MOVING

#     # Step 2: 충돌 발생 → wait 진입
#     robot.tick(now=time.time(), is_too_close=True)
#     assert robot.state == RobotStatus.WAIT
#     print("✔️ 첫 번째 충돌 시 wait 상태 진입")

#     # Step 3: 5초 경과 직전 또 충돌 → wait 유지
#     robot.wait_start_time -= 4.9
#     robot.tick(now=time.time(), is_too_close=True)
#     assert robot.state == RobotStatus.WAIT
#     print("✔️ 5초 경과 전 재충돌 → wait 유지")

#     # Step 4: wait 경과 후 재전송 시 충돌 없음 → moving 전환
#     robot.wait_start_time -= 6  # 총 10.9초 경과된 셈
#     robot.tick(now=time.time(), is_too_close=False)
#     assert robot.state == RobotStatus.MOVING
#     print("✔️ 5초 이상 경과 후 충돌 없음 → moving 재전환")

#     # Step 5: 배송 완료
#     robot.set_goal_finished(True)
#     robot.tick(now=time.time(), is_too_close=False)
#     assert robot.state == RobotStatus.FINISHED
#     print("✔️ 배송 완료 → 상태 finished")

#     # Step 6: returning 상태 전환
#     robot.tick(now=time.time(), is_too_close=False)
#     assert robot.state == RobotStatus.RETURNING
#     print("✔️ returning 상태 진입")

#     # Step 7: 복귀 중 충돌 → wait 진입
#     robot.tick(now=time.time(), is_too_close=True)
#     assert robot.state == RobotStatus.WAIT
#     print("✔️ 복귀 중 충돌 → wait 전환")

#     # Step 8: wait 종료 후 복귀 재개
#     robot.wait_start_time -= 6
#     robot.tick(now=time.time(), is_too_close=False)
#     assert robot.state == RobotStatus.MOVING
#     print("✔️ wait 후 복귀 goal 재전송 → moving 상태 진입")

#     # Step 9: 초기 위치 도달 → idle
#     robot.goal_finished = False  # ✅ 상태 오염 방지
#     robot.current_pose.position.x = 0.0
#     robot.current_pose.position.y = 0.0
#     robot.tick(now=time.time(), is_too_close=False)
#     assert robot.state == RobotStatus.IDLE
#     print("✔️ 초기 위치 도달 → 상태 idle 복귀")

#     print("\n✅ 모든 충돌 및 대기 시나리오 테스트 통과!")

# if __name__ == "__main__":
#     test_robot_fsm_with_collision_loop()

import time
from collections import deque
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import PoseStamped
from builtin_interfaces.msg import Time

from TaskManager import RobotStateMachine, RobotStatus

class DummyPublisher:
    def __init__(self, name):
        self.name = name
    def publish(self, msg):
        print(f"📤 [{self.name}] publish: {msg.data}")

class DummyLogger:
    def info(self, msg): print(f"[INFO] {msg}")
    def warn(self, msg): print(f"[WARN] {msg}")

def create_test_pose(x, y):
    pose = PoseStamped()
    pose.header.stamp = Time()
    pose.pose.position.x = x
    pose.pose.position.y = y
    pose.pose.orientation.w = 1.0
    return pose

def test_multiple_goals_assignment():
    print("🚀 3개 이상의 goal 할당 테스트 시작\n")

    # 초기화
    robot_names = ["robot8", "robot9"]
    robots = {}
    for name in robot_names:
        init_pose = create_test_pose(0.0 if name == "robot8" else 1.0, 0.0)
        robots[name] = RobotStateMachine(
            name=name,
            init_pose=init_pose,
            publisher=DummyPublisher(name),
            logger=DummyLogger()
        )

    # 작업 큐 4개 (로봇 수보다 많음)
    goal_queue = deque([
        create_test_pose(2.0, 2.0),
        create_test_pose(3.0, 3.0),
        create_test_pose(4.0, 4.0),
        create_test_pose(5.0, 5.0),
    ])

    tick = 0
    while tick < 20:
        print(f"\n🔄 Tick {tick}")
        now = time.time()

        # 단순 충돌 없음 시나리오
        close = False

        # 상태 전이 및 goal 할당
        for name, robot in robots.items():
            # 특정 Tick에서 작업 완료 시뮬레이션
            if robot.state == RobotStatus.MOVING and tick in [4, 6, 10, 12]:
                robot.set_goal_finished(True)
            if robot.state == RobotStatus.RETURNING and tick in [7, 9, 13, 15]:
                robot.current_pose.position.x = 0.0 if name == "robot8" else 1.0
                robot.current_pose.position.y = 0.0

            robot.tick(now, is_too_close=close)

            # IDLE이면 작업 할당
            if robot.state == RobotStatus.IDLE and goal_queue:
                next_goal = goal_queue.popleft()
                robot.assign_goal(next_goal)

        tick += 1
        time.sleep(0.3)

    print("\n✅ 테스트 종료: 모든 goal이 순차적으로 할당되었는지 로그를 확인하세요.")

if __name__ == "__main__":
    test_multiple_goals_assignment()
