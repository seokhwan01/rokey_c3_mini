import cv2
import matplotlib.pyplot as plt

# 경로 및 맵 정보
image_path = '/home/choi/rokey_c3_mini/src/mini_project/map/map.pgm'
origin_x, origin_y = -7.51, -0.89
resolution = 0.05

# 실제 지우고 싶은 영역 (월드 좌표 기준)
# x_min, x_max = -0.0377, 0.213
# y_min, y_max = 1.43, 1.84
x_min, x_max = -0.1, 0.24
y_min, y_max = 1.2, 2.0

# 이미지 로딩
img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
height, width = img.shape

# 월드 → 픽셀 좌표 변환
def world_to_pixel(x, y):
    px = int((x - origin_x) / resolution)
    py = int(height - (y - origin_y) / resolution)
    return px, py

# 영역 변환
px_min, py_max = world_to_pixel(x_min, y_min)
px_max, py_min = world_to_pixel(x_max, y_max)

# 네모 영역 제거 (장애물 → 빈 공간)
img[py_min:py_max, px_min:px_max] = 255  # 흰색으로 변경

# 결과 저장
cv2.imwrite('map_modified.pgm', img)

# 시각화
plt.imshow(img, cmap='gray')
plt.title('Modified Map')
plt.show()
